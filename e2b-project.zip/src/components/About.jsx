import React from 'react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              About New Jersey Cleaning Services
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              We are a professional cleaning company based in Garfield, NJ, dedicated to providing exceptional cleaning services throughout New Jersey. With years of experience in the industry, we have built a reputation for reliability, thoroughness, and customer satisfaction.
            </p>
            <p className="text-lg text-gray-600 mb-6">
              Our team of trained professionals uses eco-friendly products and proven techniques to ensure your space is not only clean but healthy for you and your family.
            </p>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h3 className="text-2xl font-bold text-blue-600 mb-2">10+</h3>
                <p className="text-gray-600">Years of Experience</p>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-blue-600 mb-2">500+</h3>
                <p className="text-gray-600">Happy Customers</p>
              </div>
            </div>
          </div>
          <div className="bg-blue-600 rounded-lg p-8 text-white">
            <h3 className="text-2xl font-bold mb-6">Why Choose Us?</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <span className="text-green-400 mr-3">✓</span>
                <span>Professional and reliable service</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-400 mr-3">✓</span>
                <span>Eco-friendly cleaning products</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-400 mr-3">✓</span>
                <span>Flexible scheduling options</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-400 mr-3">✓</span>
                <span>Competitive pricing</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-400 mr-3">✓</span>
                <span>100% satisfaction guarantee</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;