import React from 'react';

const Hero = () => {
  return (
    <section id="home" className="bg-blue-600 text-white py-20 lg:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
          Professional Cleaning Services in New Jersey
        </h2>
        <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
          Top-tier house cleaning across Glen Rock, NJ, specializing in dependable and thorough cleaning solutions
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="#contact"
            className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-all duration-200 transform hover:scale-105 shadow-lg"
          >
            Get Free Quote
          </a>
          <a
            href="#services"
            className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-all duration-200 transform hover:scale-105"
          >
            Our Services
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;