import React from 'react';

const Services = () => {
  const services = [
    {
      title: "House Cleaning",
      description: "Comprehensive house cleaning services tailored to your needs",
      icon: "🏠"
    },
    {
      title: "Deep Cleaning",
      description: "Thorough deep cleaning for a spotless home environment",
      icon: "✨"
    },
    {
      title: "Move-in/Move-out Cleaning",
      description: "Professional cleaning for your moving needs",
      icon: "📦"
    },
    {
      title: "Regular Maintenance",
      description: "Scheduled cleaning services to keep your home pristine",
      icon: "🧹"
    },
    {
      title: "Office Cleaning",
      description: "Professional office and commercial space cleaning",
      icon: "🏢"
    },
    {
      title: "Post-Construction",
      description: "Specialized cleaning after construction and renovations",
      icon: "🔨"
    }
  ];

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Cleaning Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We offer a wide range of professional cleaning services to meet your specific needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-gray-50 rounded-lg p-8 shadow-md hover:shadow-xl transition-all duration-300 transform hover:scale-105"
            >
              <div className="text-4xl mb-4">{service.icon}</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;